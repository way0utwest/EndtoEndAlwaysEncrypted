USE AlwaysEncryptedDemo
GO
--SELECT top 10
--  'sql2014', *
-- FROM customers;
-- GO
 SELECT top 10
  'sql2016', *
 FROM customers
GO
 --SELECT top 10
 -- 'vm - sql2016', *
 --FROM customers
