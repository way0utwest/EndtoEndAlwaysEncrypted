/*
End to End Always Encrypted - Verify Certificate

Steve Jones, copyright 2016

This code is provided as is for demonstration purposes. It may not be suitable for
your environment. Please test this on your own systems. This code may not be republished 
or redistributed by anyone without permission.
You are free to use this code inside of your own organization.
*/

-- Export certificate from local machine
-- \Documents\GitHub\EndtoEndAlwaysEncrypted\Certificates

-- name?

-- Check folder
-- \Documents\GitHub\EndtoEndAlwaysEncrypted\Certificates


-- delete certificate from user certificates from local store.

-- Requery
EXEC dbo.Customers_SelectAll;



-- Encrypted?




-- Move to VM
-- Run app


-- Copy cert to VM
-- Load User Certificates app
-- Import certificate
-- requery from app

